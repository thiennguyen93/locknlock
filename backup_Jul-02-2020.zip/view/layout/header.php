<header class="head">
    <div class="hd-top"><img src="./images/hd1.jpg"></div>
    <div class="hd-main">bán buôn bán lẻ đầm bầu thời trang</div>
    <div class="hd-bottom">
        <div><img src="./images/hd2.png"><p class="hd-p">Tel: 0867.453.994</p></div>
        <div><img src="./images/hd2.png"><p class="hd-p">Hương: 0867.453.994</p></div>
        <div><img src="./images/hd2.png"><p class="hd-p">Hiền: 0867.453.994</p></div>
    </div>
</header>