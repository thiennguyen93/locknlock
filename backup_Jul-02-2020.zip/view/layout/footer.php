<footer class="footer">
    <div class="f-top">
        <ul>
            <li><a>Liên hệ</a></li>
            <li><a>Sản phẩm</a></li>
            <li><a>Dịch vụ</a></li>
            <li><a>Giới thiệu</a></li>
            <li><a>Trang chủ</a></li>
        </ul>
    </div>
    <div class="f-bottom">&copy; 2014 Designed by Web Designer <span>PHP 2003</span></div>
</footer>