<?php
var_dump($fdata);
?>
<p class="mb-td">Sản phẩm</p>
<div class="product">

<div class="m-product">
        <img src="<?=$data['data']['hinh']?>">
        <p><?=$data['data']['ten']?></p>
        <p class="price"><?=$data['data']['gia']?></p>
        <img src="./images/sao.png">
        <br>
        <img src="./images/mua.png">
    </div>


</div>